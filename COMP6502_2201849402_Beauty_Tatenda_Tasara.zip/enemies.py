import pygame
import random


from player import *

SCREEN_WIDTH = 800
SCREEN_HEIGHT = 700

# Define colors
BLACK = (0,0,0)
WHITE = (255,255,255)
GREEN = (0,255,0)
RED = (255,0,0)
PINK = (255,105,180)

class Block(pygame.sprite.Sprite):
    """a class to represent the blocks or walls where the player and enemy cant go"""
    def __init__(self,x,y,color,width,height):
        # Call the parent class (Sprite) constructor
        pygame.sprite.Sprite.__init__(self)
        # Set the background color and set it to be transparent
        self.image = pygame.Surface([width,height])
        self.image.fill(color)
        self.rect = self.image.get_rect()
        self.rect.topleft = (x,y)


class Ellipse(pygame.sprite.Sprite):
    """class to represent the dot or coin in the game to be collected by player"""
    def __init__(self,x,y,color,width,height):
        # Call the parent class (Sprite) constructor
        pygame.sprite.Sprite.__init__(self)
        # Set the background color and set it to be transparent
        self.image = pygame.Surface([width,height])
        self.image.fill(BLACK)
        self.image.set_colorkey(BLACK)
        # Draw the ellipse
        pygame.draw.ellipse(self.image,color,[0,0,width,height])
        self.rect = self.image.get_rect()
        self.rect.topleft = (x,y)

        
class Slime(pygame.sprite.Sprite):
    """a class to represent the enemy,contains settings,defines movement and defines walls"""
    def __init__(self,x,y,change_x,change_y):
        # Call the parent class (Sprite) constructor
        pygame.sprite.Sprite.__init__(self)
        # Set the direction of the slime
        self.change_x = change_x
        self.change_y = change_y
        # Load image
        self.image = pygame.image.load("slime.png").convert_alpha()
        self.rect = self.image.get_rect()
        self.rect.topleft = (x,y)


    def update(self, horizontal_blocks, vertical_blocks, left_blocks, right_blocks, top_blocks, bottom_blocks, S_blocks, X_blocks,
               B_blocks, G_blocks):
        self.rect.x += self.change_x
        self.rect.y += self.change_y
        if self.rect.right < 0:
            self.rect.left = SCREEN_WIDTH
        elif self.rect.left > SCREEN_WIDTH:
            self.rect.right = 0
        if self.rect.bottom < 0:
            self.rect.top = SCREEN_HEIGHT
        elif self.rect.top > SCREEN_HEIGHT:
            self.rect.bottom = 0

        #defines the path of the enemy ,walls
        for block in pygame.sprite.spritecollide(self,horizontal_blocks,False):
            self.rect.centery = block.rect.centery
            self.change_y = 0

        for block in pygame.sprite.spritecollide(self,vertical_blocks,False):
            self.rect.centerx = block.rect.centerx
            self.change_x = 0

        direction = random.choice(("left","right","up","down"))
        for block in pygame.sprite.spritecollide(self, right_blocks, False):
            if self.change_x > 0:
                self.rect.centerx = block.rect.centerx
                if direction == "left" and self.change_x == 0:
                    self.change_x = -2
                    self.change_y = 0
                elif direction == "up" and self.change_y == 0:
                    self.change_x = 0
                    self.change_y = -2
                elif direction == "down" and self.change_y == 0:
                    self.change_x = 0
                    self.change_y = 2


        for block in pygame.sprite.spritecollide(self,left_blocks,False):
            if self.change_x < 0:
                self.rect.centerx = block.rect.centerx
                self.rect.centerx = block.rect.centerx
                if direction == "right" and self.change_x == 0:
                    self.change_x = 2
                    self.change_y = 0
                elif direction == "up" and self.change_y == 0:
                    self.change_x = 0
                    self.change_y = -2
                elif direction == "down" and self.change_y == 0:
                    self.change_x = 0
                    self.change_y = 2


        for block in pygame.sprite.spritecollide(self,top_blocks,False):
            if self.change_y < 0:
                self.rect.centery = block.rect.centery
                if direction == "left" and self.change_x == 0:
                    self.change_x = -2
                    self.change_y = 0
                elif direction == "right" and self.change_x == 0:
                    self.change_x = 2
                    self.change_y = 0
                elif direction == "down" and self.change_y == 0:
                    self.change_x = 0
                    self.change_y = 2


        for block in pygame.sprite.spritecollide(self,bottom_blocks,False):
            if self.change_y > 0:
                self.rect.centery = block.rect.centery
                if direction == "left" and self.change_x == 0:
                    self.change_x = -2
                    self.change_y = 0
                elif direction == "right" and self.change_x == 0:
                    self.change_x = 2
                    self.change_y = 0
                elif direction == "up" and self.change_y == 0:
                    self.change_x = 0
                    self.change_y = -2



        for block in pygame.sprite.spritecollide(self,S_blocks,False):
            if self.change_y < 0:
                self.rect.centery = block.rect.centery
                if direction == "left" and self.change_x == 0:
                    self.change_x = -2
                    self.change_y = 0
                elif direction == "right" and self.change_x == 0:
                    self.change_x = 2
                    self.change_y = 0
                elif direction == "down" and self.change_y == 0:
                    self.change_x = 0
                    self.change_y = 2

            elif self.change_x > 0:
                self.rect.centerx = block.rect.centerx
                if direction == "left" and self.change_x == 0:
                    self.change_x = -2
                    self.change_y = 0
                elif direction == "up" and self.change_y == 0:
                    self.change_x = 0
                    self.change_y = -2
                elif direction == "down" and self.change_y == 0:
                    self.change_x = 0
                    self.change_y = 2


        for block in pygame.sprite.spritecollide(self,X_blocks,False):
            if self.change_x > 0:
                self.rect.centerx = block.rect.centerx
                if direction == "left" and self.change_x == 0:
                    self.change_x = -2
                    self.change_y = 0
                elif direction == "up" and self.change_y == 0:
                    self.change_x = 0
                    self.change_y = -2
                elif direction == "down" and self.change_y == 0:
                    self.change_x = 0
                    self.change_y = 2

            elif self.change_y > 0:
                self.rect.centery = block.rect.centery
                if direction == "left" and self.change_x == 0:
                    self.change_x = -2
                    self.change_y = 0
                elif direction == "right" and self.change_x == 0:
                    self.change_x = 2
                    self.change_y = 0
                elif direction == "up" and self.change_y == 0:
                    self.change_x = 0
                    self.change_y = -2


        for block in pygame.sprite.spritecollide(self,B_blocks,False):
            if self.change_y > 0:
                self.rect.centery = block.rect.centery
                self.rect.centery = block.rect.centery
                if direction == "left" and self.change_x == 0:
                    self.change_x = -2
                    self.change_y = 0
                elif direction == "right" and self.change_x == 0:
                    self.change_x = 2
                    self.change_y = 0
                elif direction == "up" and self.change_y == 0:
                    self.change_x = 0
                    self.change_y = -2

            elif self.change_x < 0:
                self.rect.centerx = block.rect.centerx
                if direction == "right" and self.change_x == 0:
                    self.change_x = 2
                    self.change_y = 0
                elif direction == "up" and self.change_y == 0:
                    self.change_x = 0
                    self.change_y = -2
                elif direction == "down" and self.change_y == 0:
                    self.change_x = 0
                    self.change_y = 2


        for block in pygame.sprite.spritecollide(self,G_blocks,False):
            if self.change_y < 0:
                self.rect.centery = block.rect.centery
                self.rect.centery = block.rect.centery
                if direction == "left" and self.change_x == 0:
                    self.change_x = -2
                    self.change_y = 0
                elif direction == "right" and self.change_x == 0:
                    self.change_x = 2
                    self.change_y = 0
                elif direction == "down" and self.change_y == 0:
                    self.change_x = 0
                    self.change_y = 2

            elif self.change_x < 0:
                self.rect.centerx = block.rect.centerx
                if direction == "right" and self.change_x == 0:
                    self.change_x = 2
                    self.change_y = 0
                elif direction == "up" and self.change_y == 0:
                    self.change_x = 0
                    self.change_y = -2
                elif direction == "down" and self.change_y == 0:
                    self.change_x = 0
                    self.change_y = 2

        #controls the movement of enemy on intersection points

        if self.rect.topleft in self.get_intersection_position():
            direction = random.choice(("left","right","up","down"))
            if direction == "left" and self.change_x == 0:
                self.change_x = -2
                self.change_y = 0
            elif direction == "right" and self.change_x == 0:
                self.change_x = 2
                self.change_y = 0
            elif direction == "up" and self.change_y == 0:
                self.change_x = 0
                self.change_y = -2
            elif direction == "down" and self.change_y == 0:
                self.change_x = 0
                self.change_y = 2

        if self.rect.topleft in self.get_turning_points():
            direction = random.choice(("left","right","down"))
            if direction == "left" and self.change_x == 0:
                self.change_x = -2
                self.change_y = 0
            elif direction == "right" and self.change_x == 0:
                self.change_x = 2
                self.change_y = 0
            elif direction == "down" and self.change_y == 0:
                self.change_x = 0
                self.change_y = 2

        if self.rect.topleft in self.get_turn():
            direction = random.choice(("left","right","up"))
            if direction == "left" and self.change_x == 0:
                self.change_x = -2
                self.change_y = 0
            elif direction == "right" and self.change_x == 0:
                self.change_x = 2
                self.change_y = 0
            elif direction == "up" and self.change_y == 0:
                self.change_x = 0
                self.change_y = -2

        if self.rect.topleft in self.get_corner():
            direction = random.choice(("right","up","down"))
            if direction == "right" and self.change_x == 0:
                self.change_x = 2
                self.change_y = 0
            elif direction == "up" and self.change_y == 0:
                self.change_x = 0
                self.change_y = -2
            elif direction == "down" and self.change_y == 0:
                self.change_x = 0
                self.change_y = 2

        if self.rect.topleft in self.get_turning():
            direction = random.choice(("left","up","down"))
            if direction == "left" and self.change_x == 0:
                self.change_x = -2
                self.change_y = 0
            elif direction == "up" and self.change_y == 0:
                self.change_x = 0
                self.change_y = -2
            elif direction == "down" and self.change_y == 0:
                self.change_x = 0
                self.change_y = 2




    def get_turning_points(self):
        items = []
        for i,row in enumerate(enviroment()):
            for j,item in enumerate(row):
                if item == 4:
                    items.append((j*32,i*32))
                    return items




    def get_intersection_position(self):
        items = []
        for i,row in enumerate(enviroment()):
            for j,item in enumerate(row):
                if item == 3:
                    items.append((j*32,i*32))
        return items



    def get_turn(self):
        items = []
        for i,row in enumerate(enviroment()):
            for j,item in enumerate(row):
                if item == 5:
                    items.append((j*32,i*32))
        return items



    def get_corner(self):
        items = []
        for i,row in enumerate(enviroment()):
            for j,item in enumerate(row):
                if item == 8:
                    items.append((j*32,i*32))
        return items



    def get_turning(self):
        items = []
        for i,row in enumerate(enviroment()):
            for j,item in enumerate(row):
                if item == 7:
                    items.append((j*32,i*32))
        return items



class Ghost(Slime):
    """a subclass of Slime which adds more enemy after score of 50"""
    def __init__(self,x,y,change_x,change_y):
        super().__init__(x,y,change_x,change_y)
        self.image = pygame.image.load("evil.png").convert_alpha()



class Pinky(Slime):
    """a subclass of Slime which adds ghost that appear after score of 75"""
    def __init__(self,x,y,change_x,change_y):
        super().__init__(x,y,change_x,change_y)
        self.image = pygame.image.load("pinky.png").convert_alpha()




        
def enviroment():
    """a function to write the maze"""
    grid = ((0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,),
            (0,'G',1,1,1,1,1,1,1,4,1,1,1,1,1,1,1,4,1,1,1,1,1,'S',0,),
            (0,2,0,0,0,0,0,0,0,2,0,0,0,0,0,0,0,2,0,0,0,0,0,2,0,),
            (0,2,0,0,0,0,0,0,0,2,0,0,0,0,0,0,0,2,0,0,0,0,0,2,0,),
            (0,8,1,1,1,1,1,1,1,3,1,1,1,1,1,1,1,3,1,1,1,1,1,7,0,),
            (0,2,0,0,0,0,0,0,0,2,0,0,0,0,0,0,0,2,0,0,0,0,0,2,0,),
            (0,2,0,0,0,0,0,0,0,2,0,0,0,0,0,0,0,2,0,0,0,0,0,2,0,),
            (0,2,0,0,0,0,0,0,0,2,0,0,0,0,0,0,0,2,0,0,0,0,0,2,0,),
            (0,8,1,1,1,1,1,1,1,3,1,1,1,1,1,1,1,3,1,1,1,1,1,7,0,),
            (0,2,0,0,0,0,0,0,0,2,0,0,0,0,0,0,0,2,0,0,0,0,0,2,0,),
            (0,2,0,0,0,0,0,0,0,2,0,0,0,0,0,0,0,2,0,0,0,0,0,2,0,),
            (0,2,0,0,0,0,0,0,0,2,0,0,0,0,0,0,0,2,0,0,0,0,0,2,0,),
            (0,8,1,1,1,1,1,1,1,3,1,1,1,1,1,1,1,3,1,1,1,1,1,7,0,),
            (0,2,0,0,0,0,0,0,0,2,0,0,0,0,0,0,0,2,0,0,0,0,0,2,0,),
            (0,2,0,0,0,0,0,0,0,2,0,0,0,0,0,0,0,2,0,0,0,0,0,2,0,),
            (0,2,0,0,0,0,0,0,0,2,0,0,0,0,0,0,0,2,0,0,0,0,0,2,0,),
            (0,8,1,1,1,1,1,1,1,3,1,1,1,1,1,1,1,3,1,1,1,1,1,7,0,),
            (0,2,0,0,0,0,0,0,0,2,0,0,0,0,0,0,0,2,0,0,0,0,0,2,0,),
            (0,2,0,0,0,0,0,0,0,2,0,0,0,0,0,0,0,2,0,0,0,0,0,2,0,),
            (0,2,0,0,0,0,0,0,0,2,0,0,0,0,0,0,0,2,0,0,0,0,0,2,0,),
            (0,'B',1,1,1,1,1,1,1,5,1,1,1,1,1,1,1,5,1,1,1,1,1,'X',0,),
            (0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,))

    return grid

def draw_enviroment(screen):
    """a function to draw the lines that appear in the game"""
    for i,row in enumerate(enviroment()):
        for j,item in enumerate(row):
            if item == 1:
                pygame.draw.line(screen, PINK, [j * 32, i * 32], [j * 32 + 32, i * 32], 3)
                pygame.draw.line(screen, PINK, [j * 32, i * 32 + 32], [j * 32 + 32, i * 32 + 32], 3)
            elif item == 2:
                pygame.draw.line(screen, PINK, [j * 32, i * 32], [j * 32, i * 32 + 32], 3)
                pygame.draw.line(screen, PINK, [j * 32 + 32, i * 32], [j * 32 + 32, i * 32 + 32], 3)
            elif item == 4:
                pygame.draw.line(screen, PINK, [j * 32, i * 32], [j * 32 + 32, i * 32], 3)
            elif item == 5:
                pygame.draw.line(screen, PINK, [j * 32, i * 32 + 32], [j * 32 + 32, i * 32 + 32], 3)
            elif item == 8:
                pygame.draw.line(screen, PINK, [j * 32, i * 32], [j * 32, i * 32 + 32], 3)
            elif item == 7:
                pygame.draw.line(screen, PINK, [j * 32 + 32, i * 32], [j * 32 + 32, i * 32 + 32], 3)
            elif item == 'G':
                 pygame.draw.line(screen, PINK, [j * 32, i * 32], [j * 32 + 32, i * 32], 3)
                 pygame.draw.line(screen, PINK, [j * 32, i * 32], [j * 32, i * 32 + 32], 3)
            elif item == 'B':
                pygame.draw.line(screen, PINK, [j * 32, i * 32], [j * 32, i * 32 + 32], 3)
                pygame.draw.line(screen, PINK, [j * 32, i * 32 + 32], [j * 32 + 32, i * 32 + 32], 3)
            elif item == 'X':
                pygame.draw.line(screen, PINK, [j * 32 + 32, i * 32], [j * 32 + 32, i * 32 + 32], 3)
                pygame.draw.line(screen, PINK, [j * 32, i * 32 + 32], [j * 32 + 32, i * 32 + 32], 3)
            elif item == 'S':
                pygame.draw.line(screen, PINK, [j * 32 + 32, i * 32], [j * 32 + 32, i * 32 + 32], 3)
                pygame.draw.line(screen, PINK, [j * 32, i * 32], [j * 32 + 32, i * 32], 3)


