import pygame
from player import Player
from enemies import *

#set the screen
SCREEN_WIDTH = 800
SCREEN_HEIGHT = 700

# Define some colors
BLACK = (0,0,0)
WHITE = (255,255,255)
BLUE = (0,0,255)
RED = (255,0,0)
PINK = (255,105,180)

class Game():
    """a class to contain all the game functions and settings"""

    def __init__(self):
        self.font = pygame.font.Font(None,100)
        self.about = False
        self.game_over = True
        # Create the variable for the score
        self.score = 0
        # Create the font for displaying the score on the screen
        self.font = pygame.font.Font(None,35)
        # Create the menu of the game
        self.menu = Menu(("start","about","exit"),font_color = WHITE,font_size=60)
        # Create the player
        #parameters are x,y, filename
        self.player = Player(32,128,"player.png")
        # Load the sound effects
        self.pacman_sound = pygame.mixer.Sound("pacman_sound.ogg")
        self.game_over_sound = pygame.mixer.Sound("game_over_sound.ogg")
        # Create the blocks that will set the paths where the player can go
        self.horizontal_blocks = pygame.sprite.Group()
        self.vertical_blocks = pygame.sprite.Group()
        self.right_blocks = pygame.sprite.Group()
        self.left_blocks = pygame.sprite.Group()
        self.top_blocks = pygame.sprite.Group()
        self.bottom_blocks = pygame.sprite.Group()
        self.S_blocks = pygame.sprite.Group()
        self.B_blocks = pygame.sprite.Group()
        self.X_blocks = pygame.sprite.Group()
        self.G_blocks = pygame.sprite.Group()

        # Create a group for the dots on the screen
        self.dots_group = pygame.sprite.Group()


        # Set the enviroment:
        #parameters: 'x', 'y', 'color', 'width', and 'height'

        for i,row in enumerate(enviroment()):
            for j,item in enumerate(row):
                if item == 1:
                    self.horizontal_blocks.add(Block(j*32+8, i*32+8, BLACK, 16, 16))
                elif item == 2:
                    self.vertical_blocks.add(Block(j*32+8, i*32+8, BLACK, 16, 16))
                elif item == 7:
                    self.right_blocks.add(Block(j * 32 + 8, i * 32 + 8, BLACK, 16, 16))
                elif item == 8:
                    self.left_blocks.add(Block(j*32+8, i*32+8, BLACK, 16, 16))
                elif item == 4:
                    self.top_blocks.add(Block(j*32+8, i*32+8, BLACK, 16, 16))
                elif item == 5:
                    self.bottom_blocks.add(Block(j*32+8, i*32+8, BLACK, 16, 16))
                elif item == 'X':
                    self.X_blocks.add(Block(j*32+8, i*32+8, BLACK, 16, 16))
                elif item == 'S':
                    self.S_blocks.add(Block(j*32+8, i*32+8, BLACK, 16, 16))
                elif item == 'B':
                    self.B_blocks.add(Block(j*32+8, i*32+8, BLACK, 16, 16))
                elif item == 'G':
                    self.G_blocks.add(Block(j*32+8, i*32+8, BLACK, 16, 16))

        # Create the enemies
        self.enemies = pygame.sprite.Group()
        self.enemies.add(Slime(288,96,0,2))
        self.enemies.add(Slime(288,320,0,-2))
        self.enemies.add(Slime(544,128,0,2))
        self.enemies.add(Slime(288,96,0,2))
        self.enemies.add(Slime(288,320,0,-2))
        self.enemies.add(Slime(32,32,2,0))


        self.evil = pygame.sprite.Group()
        self.evil.add(Ghost(96,32,2,0))
        self.evil.add(Ghost(608,128,2,0))
        self.evil.add(Ghost(640,32,2,0))


        self.villain = pygame.sprite.Group()
        self.villain.add(Pinky(288,320,0,-2))
        self.villain.add(Pinky(288,96,0,2))
        self.villain.add(Pinky(288,320,0,-2))
        self.villain.add(Pinky(32,32,2,0))



        # Add the coin or dots inside the game
        for i, row in enumerate(enviroment()):
            for j, item in enumerate(row):
                if item != 0 and item != 6 :
                    self.dots_group.add(Ellipse(j*32+12,i*32+12,WHITE,8,8))


    def process_events(self):
        """function to process keypress or user input"""

        for event in pygame.event.get(): # User did something
            if event.type == pygame.QUIT: # If user clicked close
                return True
            #menu keypress response
            self.menu.event_handler(event)
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_RETURN:
                    if self.game_over and not self.about:
                        if self.menu.state == 0:
                            # ---- START ------
                            self.__init__()  #initialize pygame
                            self.game_over = False
                        elif self.menu.state == 1:
                            # --- ABOUT ------
                            self.about = True
                        elif self.menu.state == 2:
                            # --- EXIT -------
                            # User clicked exit
                            return True

                #player keypress response in game continuous motion
                elif event.key == pygame.K_RIGHT:
                    self.player.move_right()

                elif event.key == pygame.K_LEFT:
                    self.player.move_left()

                elif event.key == pygame.K_UP:
                    self.player.move_up()

                elif event.key == pygame.K_DOWN:
                    self.player.move_down()



                elif event.key == pygame.K_ESCAPE:
                    self.game_over = True
                    self.about = False

            #not continuous motion
            elif event.type == pygame.KEYUP:
                if event.key == pygame.K_RIGHT:
                    self.player.stop_move_right()
                elif event.key == pygame.K_LEFT:
                    self.player.stop_move_left()
                elif event.key == pygame.K_UP:
                    self.player.stop_move_up()
                elif event.key == pygame.K_DOWN:
                    self.player.stop_move_down()

            elif event.type == pygame.MOUSEBUTTONDOWN:
                self.player.explosion = False
                    
        return False

    def run_logic(self,screen):
        """this function determines the logic of the game and order of events"""

        if not self.game_over:
            self.player.update(self.horizontal_blocks, self.vertical_blocks, self.left_blocks, self.right_blocks,
                               self.top_blocks, self.bottom_blocks, self.S_blocks, self.X_blocks,
                               self.B_blocks, self.G_blocks)
            block_hit_list = pygame.sprite.spritecollide(self.player,self.dots_group,True)
            # When the block_hit_list contains one sprite that means that player hit a dot

            if len(block_hit_list) > 0:
                # Here will be the sound effect
                self.pacman_sound.play()
                self.score += 1

           # counter = len (block_hit_list)
            if len(block_hit_list) > 5:
                self.score = len(block_hit_list)
                #self.score = counter


            if (self.score) > 50:
                evil_collide = pygame.sprite.spritecollide(self.player,self.evil,True)
                if len(evil_collide) > 0:
                    self.player.explosion = True
                    self.game_over_sound.play()


            if (self.score) > 75:
                villain_collide = pygame.sprite.spritecollide(self.player,self.villain,True)
                if len(villain_collide) > 0:
                    self.player.explosion = True
                    self.game_over_sound.play()


            if len(block_hit_list) > 193:
                self.score = 193


            enemies_collide = pygame.sprite.spritecollide(self.player,self.enemies,True)


            if len(enemies_collide) > 0:
                self.player.explosion = True
                self.game_over_sound.play()

            self.game_over = self.player.game_over
            self.enemies.update(self.horizontal_blocks, self.vertical_blocks, self.left_blocks, self.right_blocks,
                                self.top_blocks, self.bottom_blocks, self.S_blocks, self.X_blocks,
                                self.B_blocks, self.G_blocks)
            self.evil.update(self.horizontal_blocks, self.vertical_blocks, self.left_blocks, self.right_blocks,
                             self.top_blocks, self.bottom_blocks, self.S_blocks, self.X_blocks,
                             self.B_blocks, self.G_blocks)
            self.villain.update(self.horizontal_blocks, self.vertical_blocks, self.left_blocks, self.right_blocks,
                                self.top_blocks, self.bottom_blocks, self.S_blocks, self.X_blocks,
                                self.B_blocks, self.G_blocks)


    def display_frame(self,screen):
        """this function draws the sprites,score,text on the screen"""

        # First, clear the screen to black. no other drawing commands
        screen.fill(BLACK)
        # --- Drawing code should go here
        if self.game_over:
            if self.about:
                self.display_message(screen,"This game was created by BEAUTY")
            else:
                self.menu.display_frame(screen)
        else:
            # --- Draw the game here ---
            self.horizontal_blocks.draw(screen)
            self.vertical_blocks.draw(screen)
            self.right_blocks.draw(screen)
            self.left_blocks.draw(screen)
            self.top_blocks.draw(screen)
            self.top_blocks.draw(screen)
            self.B_blocks.draw(screen)
            self.X_blocks.draw(screen)
            self.G_blocks.draw(screen)
            self.S_blocks.draw(screen)
            draw_enviroment(screen)
            self.dots_group.draw(screen)
            self.enemies.draw(screen)
            if self.score > 50:
                self.evil.draw(screen)
            if self.score > 75:
                self.villain.draw(screen)

            screen.blit(self.player.image,self.player.rect)
            # Render the text for the score
            text = self.font.render("Score: " + str(self.score),True,WHITE)
            # Put the text on the screen
            screen.blit(text,[120,20])
            if self.score > 193:
                screen.fill(BLACK)
                end = self.font.render('YOU WIN!!!,your score is:'+ str(self.score),True,PINK)
                screen.blit(end,[200,400])



        # Update the screen with what we've drawn.
        pygame.display.flip()


    def display_message(self,screen,message,color=(PINK)):
        """function to draw the message on the screen"""

        label = self.font.render(message,True,color)
        # Get the width and height of the label
        width = label.get_width()
        height = label.get_height()
        # Determine the position of the label
        posX = (SCREEN_WIDTH /2) - (width /2)
        posY = (SCREEN_HEIGHT /2) - (height /2)
        # Draw the label onto the screen
        screen.blit(label,(posX,posY))


class Menu(object):
    """function to set the menu"""
    state = 0
    def __init__(self,items,font_color=(BLACK),select_color=(PINK),ttf_font=None,font_size=25):
        self.font_color = font_color
        self.select_color = select_color
        self.items = items
        self.font = pygame.font.Font(ttf_font,font_size)
        
    def display_frame(self,screen):
        """function to display and select the menu"""
        #items refer to start, about, exit
        for index, item in enumerate(self.items):
            if self.state == index:
                label = self.font.render(item,True,self.select_color)
            else:
                label = self.font.render(item,True,self.font_color)
            
            width = label.get_width()
            height = label.get_height()
            
            posX = (SCREEN_WIDTH /2) - (width /2)
            # t_h: total height of text block
            t_h = len(self.items) * height
            posY = (SCREEN_HEIGHT /2) - (t_h /2) + (index * height)
            
            screen.blit(label,(posX,posY))
        
    def event_handler(self,event):
        """function to control selection and keypress on menu"""
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_UP:
                if self.state > 0:
                    self.state -= 1
            elif event.key == pygame.K_DOWN:
                if self.state < len(self.items) -1:
                    self.state += 1
